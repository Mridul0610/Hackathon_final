function Mycomp(){
    return(
        <div>
            <h1>Hello my component</h1>  
            <p>This is a paragraph</p>
        </div>
    )
}
export default Mycomp